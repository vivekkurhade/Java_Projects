package com.itheima.constant;

public interface Constant {
	int USER_IS_STATE = 1;
}
