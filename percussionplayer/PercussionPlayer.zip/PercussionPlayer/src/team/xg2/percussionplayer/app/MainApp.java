package team.xg2.percussionplayer.app;

import team.xg2.percussionplayer.frame.PercussionFrame;

//Ӧ����

public class MainApp {
	public static void main(String[] args) {
		new PercussionFrame().buildGUI();
	}
}
